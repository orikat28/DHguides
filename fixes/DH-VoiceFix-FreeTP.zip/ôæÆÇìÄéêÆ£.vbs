' fix by whivipe
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
bat = dir & "\_install.bat"
If Not fso.FileExists(bat) Then
    MsgBox "Не найден установщик" & vbCrLf & dir, vbCritical, "DH reconnect — whivipe"
    WScript.Quit 1
End If
sh.CurrentDirectory = dir
sh.Run "cmd /c """ & bat & """", 1, True