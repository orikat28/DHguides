@echo off
REM fix by whivipe — FreeTP
chcp 65001 >nul
setlocal EnableDelayedExpansion

title Dread Hunger — FreeTP fix by whivipe

echo.
echo  ============================================
echo   Dread Hunger — FreeTP: войс + реконнект
echo   fix by whivipe
echo  ============================================
echo.

set "SRC=%~dp0"
set "WIN64="

if not "%~1"=="" (
    if exist "%~1\DreadHunger.exe" set "WIN64=%~1"
    if exist "%~1\..\DreadHunger.exe" set "WIN64=%~1"
)

if not defined WIN64 (
    echo  Ищу игру на дисках C, D, E...
    for %%D in (C D E) do (
        if not defined WIN64 (
            for /f "delims=" %%F in ('dir /s /b "%%D:\DreadHunger.exe" 2^>nul ^| findstr /i "\\Binaries\\Win64\\DreadHunger.exe"') do (
                if not defined WIN64 set "WIN64=%%~dpF"
            )
        )
    )
)

if not defined WIN64 (
    echo.
    echo  Не нашёл игру автоматически.
    echo  Вставь путь к папке Win64, где лежит DreadHunger.exe
    echo  Пример: E:\Dread Hunger\Dread Hunger\DreadHunger\Binaries\Win64
    echo.
    set /p "WIN64=Путь: "
    set "WIN64=!WIN64:"=!"
)

if not exist "%WIN64%\DreadHunger.exe" (
    echo.
    echo  [ОШИБКА] Тут нет DreadHunger.exe:
    echo  %WIN64%
    echo.
    pause
    exit /b 1
)

echo.
echo  Игра: %WIN64%
echo.

copy /Y "%SRC%2_EpicFix\EpicFix.ini" "%WIN64%\EpicFix.ini" >nul
copy /Y "%SRC%3_SteamFix\SteamFix.ini" "%WIN64%\SteamFix.ini" >nul
echo  [OK] EpicFix.ini + SteamFix.ini

set "SAVE_DIR=%LOCALAPPDATA%\DreadHunger\Saved\SaveData"
if not exist "%SAVE_DIR%" mkdir "%SAVE_DIR%"
copy /Y "%SRC%1_VoipSettings\VoipSettings.json" "%SAVE_DIR%\VoipSettings.json" >nul
echo  [OK] VoipSettings.json

if not exist "%WIN64%\ue4ss\UE4SS.dll" (
    echo.
    echo  [ВНИМАНИЕ] UE4SS не найден — мод войса не установится.
    echo  В FreeTP-сборке UE4SS обычно уже есть.
    echo.
) else (
    call :InstallVoiceMod
)

echo.
echo  Готово! Запусти игру. Войс пропал — CTRL+M
echo.
pause
exit /b 0

:InstallVoiceMod
if not exist "%WIN64%\ue4ss\Mods" mkdir "%WIN64%\ue4ss\Mods"
xcopy /E /I /Y "%SRC%4_VoiceReconnectFix" "%WIN64%\ue4ss\Mods\VoiceReconnectFix" >nul
echo  [OK] VoiceReconnectFix мод

set "MODS=%WIN64%\ue4ss\Mods\mods.txt"
if not exist "%MODS%" (
    echo VoiceReconnectFix : 1> "%MODS%"
    echo Keybinds : 1>> "%MODS%"
) else (
    findstr /I /C:"VoiceReconnectFix" "%MODS%" >nul
    if errorlevel 1 (
        echo.>> "%MODS%"
        echo VoiceReconnectFix : 1>> "%MODS%"
    )
)
echo  [OK] mods.txt
exit /b 0