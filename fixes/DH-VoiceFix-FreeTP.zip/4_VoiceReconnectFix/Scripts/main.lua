--[[
  DH VoiceFix v2 — fix by whivipe
  фикс голоса после дисконнекта / реконнекта

  CTRL+M = рестарт голоса, если пропал в лобби
]]

local localAppData = os.getenv("LOCALAPPDATA") or ""
local logDir = localAppData .. "\\DreadHunger\\Saved\\Logs"
local defaultLogPath = logDir .. "\\voicefix.log"

-- Маркер загрузки
do
    os.execute('mkdir "' .. logDir .. '" 2>nul')
    local boot = io.open(defaultLogPath, "a")
    if boot then
        boot:write(os.date("%Y-%m-%d %H:%M:%S") .. " [BOOT] fix by whivipe\n")
        boot:close()
    end
end

local UEHelpers = require("UEHelpers")

local Config = {
    AutoFixEnabled       = true,
    CheckIntervalMs      = 3000,
    ReinitDelayMs        = 1500,
    SecondReinitDelayMs  = 4000,
    ThirdReinitDelayMs   = 8000,
    LogVerbose           = true,
    LogToFile            = true,
    LogFilePath          = defaultLogPath,
    SettingsIniPath      = localAppData .. "\\DreadHunger\\Saved\\Config\\WindowsNoEditor\\Settings.ini",
    ForceOpenMic         = true,
    InputGainDb          = 18.0,
    InputVolume          = 1.0,
    TransmitIntervalMs   = 400,
    InputDeviceName      = "Default",
}

local lastReinitTime = 0
local reinitCooldownMs = 2000
local hadPawn = false
local lastMapName = ""
local pendingRetries = 0

local function FileLog(msg)
    if not Config.LogToFile then return end
    local f = io.open(Config.LogFilePath, "a")
    if f then
        f:write(os.date("%H:%M:%S ") .. tostring(msg) .. "\n")
        f:close()
    end
end

local function Log(msg)
    local line = "[DH_VoiceFix] " .. tostring(msg)
    print(line)
    FileLog(line)
end

local function LoadConfigFile()
    local paths = {
        "Config.txt",
    }
    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then
            for line in f:lines() do
                local k, v = line:match("^%s*([%w_]+)%s*=%s*(.+)%s*$")
                if k and v then
                    v = v:gsub("^%s+", ""):gsub("%s+$", "")
                    if k == "AutoFixEnabled" then
                        Config.AutoFixEnabled = (v:lower() == "true" or v == "1")
                    elseif k == "CheckIntervalMs" then
                        Config.CheckIntervalMs = tonumber(v) or Config.CheckIntervalMs
                    elseif k == "ReinitDelayMs" then
                        Config.ReinitDelayMs = tonumber(v) or Config.ReinitDelayMs
                    elseif k == "SecondReinitDelayMs" then
                        Config.SecondReinitDelayMs = tonumber(v) or Config.SecondReinitDelayMs
                    elseif k == "ThirdReinitDelayMs" then
                        Config.ThirdReinitDelayMs = tonumber(v) or Config.ThirdReinitDelayMs
                    elseif k == "LogVerbose" then
                        Config.LogVerbose = (v:lower() == "true" or v == "1")
                    elseif k == "ForceOpenMic" then
                        Config.ForceOpenMic = (v:lower() == "true" or v == "1")
                    elseif k == "InputGainDb" then
                        Config.InputGainDb = tonumber(v) or Config.InputGainDb
                    elseif k == "InputVolume" then
                        Config.InputVolume = tonumber(v) or Config.InputVolume
                    elseif k == "TransmitIntervalMs" then
                        Config.TransmitIntervalMs = tonumber(v) or Config.TransmitIntervalMs
                    elseif k == "LogToFile" then
                        Config.LogToFile = (v:lower() == "true" or v == "1")
                    end
                end
            end
            f:close()
            return true
        end
    end
    return false
end

local function LoadInputDeviceFromSettingsIni()
    local f = io.open(Config.SettingsIniPath, "r")
    if not f then return end
    for line in f:lines() do
        local dev = line:match("^OnlineVoice%.InputDeviceName%s*=%s*(.+)%s*$")
        if dev then
            dev = dev:gsub("^%s+", ""):gsub("%s+$", "")
            if dev ~= "" and not dev:lower():find("loop%-back", 1, true) then
                Config.InputDeviceName = dev
            end
            break
        end
    end
    f:close()
end

LoadConfigFile()
LoadInputDeviceFromSettingsIni()

local function SafeCall(label, fn)
    local ok, err = pcall(fn)
    if not ok and Config.LogVerbose then
        Log(label .. " failed: " .. tostring(err))
    end
    return ok, err
end

local function GetPlayerControllerSafe()
    local ok, pc = pcall(function()
        return UEHelpers.GetPlayerController()
    end)
    if ok and pc and pc:IsValid() then
        return pc
    end
    return nil
end

local function GetVoiceLevel()
    local pc = GetPlayerControllerSafe()
    if not pc then return nil end
    local ok, level = pcall(function()
        if pc.GetVoiceLevel then
            return pc:GetVoiceLevel()
        end
        return nil
    end)
    if ok then return level end
    return nil
end

local function CollectVoiceObjects()
    local result = {}
    local seen = {}

    local function add(obj)
        if obj and obj:IsValid() then
            local addr = obj:GetAddress()
            if addr and not seen[addr] then
                seen[addr] = true
                table.insert(result, obj)
            end
        end
    end

    for _, className in ipairs({ "DH_OnlineVoice", "UDH_OnlineVoice", "OnlineVoice" }) do
        local all = FindAllOf(className)
        if all then
            for _, obj in ipairs(all) do
                add(obj)
            end
        end
        add(FindFirstOf(className))
    end

    pcall(function()
        local gi = FindFirstOf("DH_GameInstance")
        if gi and gi:IsValid() then
            if gi.OnlineVoice then add(gi.OnlineVoice) end
            if gi.DH_OnlineVoice then add(gi.DH_OnlineVoice) end
        end
    end)

    return result
end

local function PulseWantsToTalk(voice)
    if not voice or not voice:IsValid() then return end
    SafeCall("SetWantsToTalk false", function() voice:SetWantsToTalk(false) end)
    ExecuteWithDelay(120, function()
        if voice and voice:IsValid() then
            SafeCall("SetWantsToTalk true", function() voice:SetWantsToTalk(true) end)
            if voice.bWantsToTalk ~= nil then voice.bWantsToTalk = true end
        end
    end)
end

local function FixPushToTalkWidgets()
    for _, className in ipairs({ "DH_PushToTalkWidget", "UDH_PushToTalkWidget", "PushToTalkWidget" }) do
        local widgets = FindAllOf(className)
        if widgets then
            for _, w in ipairs(widgets) do
                if w and w:IsValid() then
                    if w.bRequiresPushToTalk ~= nil then w.bRequiresPushToTalk = false end
                    if Config.ForceOpenMic and w.bWantsToTalk ~= nil then w.bWantsToTalk = true end
                end
            end
        end
    end
end

local function EnableNetworkVoiceOnPlayer()
    pcall(function()
        local pc = GetPlayerControllerSafe()
        if pc and pc:IsValid() then
            if pc.ClientEnableNetworkVoice then
                pc:ClientEnableNetworkVoice(true)
            end
            if pc.bEnableVoiceChat ~= nil then
                pc.bEnableVoiceChat = true
            end
            if Config.ForceOpenMic then
                if pc.bRequiresPushToTalk ~= nil then pc.bRequiresPushToTalk = false end
                if pc.bPushToTalk ~= nil then pc.bPushToTalk = true end
                if pc.bWantsToTalk ~= nil then pc.bWantsToTalk = true end
            end
            if pc.bHasVoiceHandshakeCompleted ~= nil then
                pc.bHasVoiceHandshakeCompleted = true
            end
            SafeCall("CreateTalkerForPlayer", function()
                if pc.CreateTalkerForPlayer then
                    pc:CreateTalkerForPlayer()
                end
            end)
            SafeCall("ClientVoiceHandshakeComplete", function()
                if pc.ClientVoiceHandshakeComplete then
                    pc:ClientVoiceHandshakeComplete()
                end
            end)
        end
    end)
    FixPushToTalkWidgets()
end

local function ApplyInputDevice(voice, deviceName)
    if not voice or not voice:IsValid() then return end
    Config.InputDeviceName = deviceName
    SafeCall("SetInputDevice", function() voice:SetInputDevice(deviceName) end)
    if voice.InputDeviceName ~= nil then voice.InputDeviceName = deviceName end
    if voice.CurrentInputDeviceName ~= nil then voice.CurrentInputDeviceName = deviceName end
end

local function ForceTransmit()
    if not Config.ForceOpenMic then return end

    EnableNetworkVoiceOnPlayer()

    for _, voice in ipairs(CollectVoiceObjects()) do
        if voice and voice:IsValid() then
            SafeCall("SetWantsToTalk", function() voice:SetWantsToTalk(true) end)
            if voice.bWantsToTalk ~= nil then voice.bWantsToTalk = true end
            if voice.WantsToTalk ~= nil then voice.WantsToTalk = true end
            if voice.bRequiresPushToTalk ~= nil then voice.bRequiresPushToTalk = false end
            if voice.bMuted ~= nil then voice.bMuted = false end
            if voice.bMicMuted ~= nil then voice.bMicMuted = false end
            if voice.InputGainDb ~= nil then voice.InputGainDb = Config.InputGainDb end
            if voice.InputVolume ~= nil then voice.InputVolume = Config.InputVolume end
        end
    end
end

local function IsVoiceHealthy(voice)
    if not voice or not voice:IsValid() then
        return false
    end

    local checks = 0
    local passed = 0

    SafeCall("IsPlayerInVoiceChat", function()
        checks = checks + 1
        if voice.IsPlayerInVoiceChat then
            if voice:IsPlayerInVoiceChat() then passed = passed + 1 end
        else
            passed = passed + 1
        end
    end)

    SafeCall("IsOnlineVoiceLoggedIn", function()
        checks = checks + 1
        if voice.IsOnlineVoiceLoggedIn then
            if voice:IsOnlineVoiceLoggedIn() then passed = passed + 1 end
        else
            passed = passed + 1
        end
    end)

    if checks == 0 then return true end
    return passed > 0
end

local function ApplyVoiceObject(voice, reason)
    if not voice or not voice:IsValid() then
        return false
    end

    local name = voice:GetFullName() or "OnlineVoice"
    if Config.LogVerbose then
        Log("Apply -> " .. name .. " (" .. reason .. ")")
    end

    SafeCall("Init", function() voice:Init() end)
    SafeCall("OnPlatformLoginComplete", function() voice:OnPlatformLoginComplete() end)
    SafeCall("RegisterEOSNotifications", function() voice:RegisterEOSNotifications() end)
    SafeCall("InitVoiceChat", function() voice:InitVoiceChat() end)

    ApplyInputDevice(voice, Config.InputDeviceName)

    if voice.InputGainDb ~= nil then voice.InputGainDb = Config.InputGainDb end
    if voice.InputVolume ~= nil then voice.InputVolume = Config.InputVolume end
    if voice.bRequiresPushToTalk ~= nil then voice.bRequiresPushToTalk = false end
    if voice.bMuted ~= nil then voice.bMuted = false end
    if voice.bMicMuted ~= nil then voice.bMicMuted = false end

    PulseWantsToTalk(voice)

    EnableNetworkVoiceOnPlayer()
    return true
end

function ReinitVoice(reason)
    local now = os.clock() * 1000
    if now - lastReinitTime < reinitCooldownMs then
        return false
    end
    lastReinitTime = now

    LoadInputDeviceFromSettingsIni()
    EnableNetworkVoiceOnPlayer()

    local voices = CollectVoiceObjects()
    if #voices == 0 then
        Log("OnlineVoice не найден (" .. reason .. ")")
        return false
    end

    local count = 0
    for _, voice in ipairs(voices) do
        if ApplyVoiceObject(voice, reason) then
            count = count + 1
        end
    end

    local level = GetVoiceLevel()
    Log(string.format("Голос перезапущен (%s), объектов: %d, level: %s",
        reason, count, tostring(level)))
    return count > 0
end

local function PrintDiagnostics()
    local pc = GetPlayerControllerSafe()
    local level = GetVoiceLevel()
    local voices = CollectVoiceObjects()

    Log("=== ДИАГНОСТИКА ===")
    Log("GetVoiceLevel: " .. tostring(level) .. (level and level > 0.01 and " (OK!)" or " (НЕТ СИГНАЛА)"))
    Log("OnlineVoice объектов: " .. #voices)

    if pc and pc:IsValid() then
        Log("PC bWantsToTalk: " .. tostring(pc.bWantsToTalk))
        Log("PC bPushToTalk: " .. tostring(pc.bPushToTalk))
        Log("PC bEnableVoiceChat: " .. tostring(pc.bEnableVoiceChat))
        Log("PC bHasVoiceHandshakeCompleted: " .. tostring(pc.bHasVoiceHandshakeCompleted))
    end

    for i, voice in ipairs(voices) do
        local inChat = "?"
        SafeCall("diag inChat", function()
            if voice.IsPlayerInVoiceChat then
                inChat = tostring(voice:IsPlayerInVoiceChat())
            end
        end)
        Log(string.format("Voice[%d] inChat=%s gain=%s vol=%s",
            i, inChat, tostring(voice.InputGainDb), tostring(voice.InputVolume)))
    end
    Log("CTRL+M=рестарт голоса")
    Log("===================")
end

local function ScheduleReinit(reason)
    pendingRetries = pendingRetries + 1
    ExecuteWithDelay(Config.ReinitDelayMs, function()
        ReinitVoice(reason .. " #1")
    end)
    ExecuteWithDelay(Config.SecondReinitDelayMs, function()
        ReinitVoice(reason .. " #2")
    end)
    ExecuteWithDelay(Config.ThirdReinitDelayMs, function()
        ReinitVoice(reason .. " #3")
        pendingRetries = math.max(0, pendingRetries - 1)
    end)
end

local function GetCurrentMapName()
    local ok, name = pcall(function()
        local pc = GetPlayerControllerSafe()
        if pc and pc:IsValid() then
            local world = pc:GetWorld()
            if world and world:IsValid() then
                return world:GetName() or ""
            end
        end
        return ""
    end)
    if ok then return name or "" end
    return ""
end

local function PlayerHasPawn()
    local pc = GetPlayerControllerSafe()
    return pc and pc:IsValid() and pc.Pawn and pc.Pawn:IsValid()
end

-- ====================== HOOKS ======================

RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    ScheduleReinit("ClientRestart")
end)

RegisterHook("/Script/Engine.PlayerController:ClientTravelInternal", function()
    ScheduleReinit("ClientTravel")
end)

RegisterHook("/Script/Engine.PlayerController:AcknowledgePossession", function()
    ScheduleReinit("AcknowledgePossession")
end)

RegisterHook("/Script/DreadHunger.DH_LobbyGameState:OnStartOnlineFinished", function()
    ScheduleReinit("LobbyOnlineFinished")
end)

RegisterHook("/Script/DreadHunger.DH_GameInstance:ConnectToURI", function()
    ScheduleReinit("ConnectToURI")
end)

RegisterHook("/Script/Engine.PlayerController:ClientEnableNetworkVoice", function()
    ExecuteWithDelay(500, function()
        ReinitVoice("After ClientEnableNetworkVoice")
    end)
end)

NotifyOnNewObject("/Script/DreadHunger.DH_OnlineVoice", function(voice)
    ExecuteWithDelay(500, function()
        ApplyVoiceObject(voice, "New DH_OnlineVoice")
    end)
end)

-- ====================== HOTKEYS ======================

-- INSERT занят BPModLoaderMod; F-клавиши — DH_Tweaks
RegisterKeyBind(Key.M, { ModifierKey.CONTROL }, function()
    lastReinitTime = 0
    LoadInputDeviceFromSettingsIni()
    if ReinitVoice("Manual (CTRL+M)") then
        PrintDiagnostics()
    else
        Log("OnlineVoice не найден. Зайди в лобби и попробуй снова.")
    end
end)

RegisterKeyBind(Key.PAUSE, function()
    lastReinitTime = 0
    LoadInputDeviceFromSettingsIni()
    if ReinitVoice("Manual (PAUSE)") then
        PrintDiagnostics()
    else
        Log("OnlineVoice не найден. Зайди в лобби и попробуй снова.")
    end
end)

RegisterKeyBind(Key.V, { ModifierKey.CONTROL }, function()
    lastReinitTime = 0
    ReinitVoice("Manual (CTRL+V)")
end)

RegisterKeyBind(Key.B, function()
    ForceTransmit()
end)

-- ====================== ПОСТОЯННАЯ ПЕРЕДАЧА ======================

LoopAsync(Config.TransmitIntervalMs, function()
    if Config.ForceOpenMic and PlayerHasPawn() then
        ForceTransmit()
    end
    return false
end)

-- ====================== AUTO MONITOR ======================

ExecuteWithDelay(4000, function()
    Log("DH_VoiceFix v2 загружен. CTRL+M = рестарт голоса после реконнекта.")
    Log("Лог: " .. Config.LogFilePath)
    ScheduleReinit("Startup")
end)

LoopAsync(Config.CheckIntervalMs, function()
    if not Config.AutoFixEnabled then
        return false
    end

    local hasPawn = PlayerHasPawn()
    local mapName = GetCurrentMapName()

    if hasPawn and not hadPawn then
        ScheduleReinit("Pawn appeared")
    end
    hadPawn = hasPawn

    if mapName ~= "" and mapName ~= lastMapName then
        if lastMapName ~= "" then
            ScheduleReinit("Map: " .. mapName)
        end
        lastMapName = mapName
    end

    if hasPawn and pendingRetries == 0 then
        local voices = CollectVoiceObjects()
        if #voices == 0 then
            ReinitVoice("Auto: no voice object")
        else
            local anyHealthy = false
            for _, voice in ipairs(voices) do
                if IsVoiceHealthy(voice) then
                    anyHealthy = true
                    break
                end
            end
            if not anyHealthy then
                ScheduleReinit("Auto: voice unhealthy")
            end
        end
    end

    return false
end)