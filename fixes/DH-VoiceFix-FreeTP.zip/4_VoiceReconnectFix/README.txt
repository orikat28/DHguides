VoiceReconnectFix — fix by whivipe
==================================

Фикс голоса после дисконнекта / реконнекта для FreeTP-сборки Dread Hunger.

CTRL+M — перезапуск голоса, если пропал в лобби.

При вопросах: Telegram @whivipe