@echo off
REM fix by whivipe — Steam
chcp 65001 >nul
setlocal EnableDelayedExpansion

title Dread Hunger — Steam fix by whivipe

echo.
echo  ============================================
echo   Dread Hunger — Steam: войс после реконнекта
echo   fix by whivipe
echo  ============================================
echo.

set "SRC=%~dp0"
set "WIN64="

if not "%~1"=="" (
    if exist "%~1\DreadHunger.exe" set "WIN64=%~1"
    if exist "%~1\..\DreadHunger.exe" set "WIN64=%~1"
)

if not defined WIN64 (
    echo  Ищу игру на дисках C, D, E...
    for %%D in (C D E) do (
        if not defined WIN64 (
            for /f "delims=" %%F in ('dir /s /b "%%D:\DreadHunger.exe" 2^>nul ^| findstr /i "\\Binaries\\Win64\\DreadHunger.exe"') do (
                if not defined WIN64 set "WIN64=%%~dpF"
            )
        )
    )
)

if not defined WIN64 (
    echo.
    echo  Не нашёл игру автоматически.
    echo  Вставь путь к папке Win64, где лежит DreadHunger.exe
    echo  Пример: C:\Program Files (x86)\Steam\steamapps\common\Dread Hunger\DreadHunger\Binaries\Win64
    echo.
    set /p "WIN64=Путь: "
    set "WIN64=!WIN64:"=!"
)

if not exist "%WIN64%\DreadHunger.exe" (
    echo.
    echo  [ОШИБКА] Тут нет DreadHunger.exe:
    echo  %WIN64%
    echo.
    pause
    exit /b 1
)

echo.
echo  Игра: %WIN64%
echo.

set "SAVE_DIR=%LOCALAPPDATA%\DreadHunger\Saved\SaveData"
if not exist "%SAVE_DIR%" mkdir "%SAVE_DIR%"
copy /Y "%SRC%1_VoipSettings\VoipSettings.json" "%SAVE_DIR%\VoipSettings.json" >nul
echo  [OK] VoipSettings.json

if not exist "%WIN64%\ue4ss\UE4SS.dll" (
    if exist "%SRC%5_UE4SS\ue4ss\UE4SS.dll" (
        echo  Ставлю UE4SS...
        if not exist "%WIN64%\dwmapi.dll" (
            copy /Y "%SRC%5_UE4SS\dwmapi.dll" "%WIN64%\dwmapi.dll" >nul
        )
        if not exist "%WIN64%\ue4ss" mkdir "%WIN64%\ue4ss"
        xcopy /E /I /Y "%SRC%5_UE4SS\ue4ss" "%WIN64%\ue4ss" >nul
        echo  [OK] UE4SS
    ) else (
        echo.
        echo  [ОШИБКА] UE4SS не найден в пакете.
        echo.
        pause
        exit /b 1
    )
)

if exist "%WIN64%\ue4ss\UE4SS.dll" (
    if not exist "%WIN64%\ue4ss\Mods" mkdir "%WIN64%\ue4ss\Mods"
    if not exist "%WIN64%\ue4ss\Mods\Keybinds" (
        xcopy /E /I /Y "%SRC%5_UE4SS\ue4ss\Mods\Keybinds" "%WIN64%\ue4ss\Mods\Keybinds" >nul 2>nul
    )
    if not exist "%WIN64%\ue4ss\Mods\shared" (
        xcopy /E /I /Y "%SRC%5_UE4SS\ue4ss\Mods\shared" "%WIN64%\ue4ss\Mods\shared" >nul 2>nul
    )
    xcopy /E /I /Y "%SRC%4_VoiceReconnectFix" "%WIN64%\ue4ss\Mods\VoiceReconnectFix" >nul
    echo  [OK] VoiceReconnectFix мод

    set "MODS=%WIN64%\ue4ss\Mods\mods.txt"
    if not exist "%MODS%" (
        echo VoiceReconnectFix : 1> "%MODS%"
        echo Keybinds : 1>> "%MODS%"
    ) else (
        findstr /I /C:"VoiceReconnectFix" "%MODS%" >nul
        if errorlevel 1 (
            echo.>> "%MODS%"
            echo VoiceReconnectFix : 1>> "%MODS%"
        )
        findstr /I /C:"Keybinds" "%MODS%" >nul
        if errorlevel 1 (
            echo Keybinds : 1>> "%MODS%"
        )
    )
    echo  [OK] mods.txt
)

echo.
echo  Готово! Запусти игру. Войс пропал — CTRL+M
echo.
pause